package com.example.ganie;

import com.squareup.otto.Bus;

public final class EventBus {
    private static final Bus BUS = new Bus();

    public static Bus getDefault() {
        return BUS;
    }

    private EventBus() {

    }
}
